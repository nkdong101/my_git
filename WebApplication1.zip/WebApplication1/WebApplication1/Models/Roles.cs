﻿using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebApplication1.Models
{
    public class Roles
    {
        [Required]
        public int ID { get; set; }
        [Column(TypeName = "nvarchar(200)")]
        public string Name { get; set; }

        public ICollection<Users>   users { get; set; }
    }
}
