﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebApplication1.Models
{
    public class Users
    {
        public int ID { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string UserName { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string  Password { get; set; }

        [Required]
        [Column(TypeName = "nvarchar(100)")]
        public string Fullname { get; set; }
        
        
        [Column(TypeName = "ntext")]
        [Required]
        public string Decription { get; set; }

        public int RoldID { get; set; }

        public Roles Roles { get; set; }
    }
}
