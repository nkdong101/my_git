﻿

using Microsoft.EntityFrameworkCore;

namespace WebApplication1.Models
{
    public class DataContext : DbContext
    {
        DbSet<Users> Users { get; set; }
        DbSet<Roles> Roles { get; set; }

        public DataContext(DbContextOptions<DataContext> options) : base(options) { }
    }
}
